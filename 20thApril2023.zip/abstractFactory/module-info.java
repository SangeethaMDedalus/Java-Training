/**
 * 
 */
/**
 * @author sm434
 *
 */
module DesignPattern {
}