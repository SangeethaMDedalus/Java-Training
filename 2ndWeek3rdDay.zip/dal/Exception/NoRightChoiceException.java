package com.dal.Exception;

public class NoRightChoiceException extends Exception{
	public NoRightChoiceException()
	{
		System.out.println("Right choice exception");
		System.out.println(" From unf excep");
	}
}
