package com.dal.Exception;

public class UserNotFoundException extends Exception{
	public UserNotFoundException()
	{
		System.out.println(" From unf excep");
	}
}
